// Select all sectors
const sectors = document.querySelectorAll('.sector');

// Select About section
const aboutSection = document.getElementById('about');

window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollBottom = scrollTop + window.innerHeight;

    sectors.forEach(sector => {
        const rect = sector.getBoundingClientRect();
        const sectorTop = rect.top + scrollTop;
        const sectorHeight = rect.height;

        // Fade-in text
        const overlayText = sector.querySelector('.overlay-text');
        if (overlayText) {
            if (scrollBottom > sectorTop + sectorHeight / 4) {
                overlayText.classList.add('visible');
            }
        }

        // Zoom background image
        const zoomSpeed = 0.2; // adjust for zoom intensity
        const offset = window.scrollY - sector.offsetTop;
        sector.style.backgroundSize = `calc(100% + ${Math.abs(offset) * zoomSpeed}px) auto`;
    });

    // Fade-in About section at page end
    if (scrollBottom > aboutSection.offsetTop + 100) { // adjust 100px for early trigger
        const overlayText = aboutSection.querySelector('.overlay-text');
        overlayText.classList.add('visible');
    }
});
